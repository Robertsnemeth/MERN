import React from 'react'

const Ad = () => {
  return (
    <div >Ad</div>
  )
}

export default Ad