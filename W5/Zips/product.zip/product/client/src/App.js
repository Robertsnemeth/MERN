import './App.css';
import ProductForm from './components/ProductForm'
import {useState} from 'react'

function App() {

const [ currentProduct, setCurrentProduct ] = useState("");

  return (
    <div className="App">
        <ProductForm currentProduct = {currentProduct} setCurrentProduct = {setCurrentProduct}/>
    </div>
  );
}

export default App;
