import React, { useState } from 'react'
import PlayerStatusTable from '../components/PlayerStatusTable'
import { Link } from 'react-router-dom';

const PlayerStatus = ({ allPlayers }) => {

  return (
    <div>
        <Link to="/team/list" className="text-3xl underline">Manage Players</Link>
        <div className='flex gap-2 text-2xl underline m-4'>
            <Link to={`/team/status/game/1`} className="hover:text-slate-500 focus:bg-slate-400 ">Game 1</Link>
            <Link to={`/team/status/game/2`} className="hover:text-slate-500 focus:bg-slate-400 ">Game 2</Link>
            <Link to={`/team/status/game/3`} className="hover:text-slate-500 focus:bg-slate-400 ">Game 3</Link>
        </div>
            <PlayerStatusTable allPlayers={allPlayers}/>
    </div>
  )
}

export default PlayerStatus