import React, { useState } from 'react'

const StatusButton = ({currentColor, status}) => {

    const [isClicked, setIsClicked ] = useState(false);

    const handleStatusChange = (e) => {
        setIsClicked(!isClicked);
    }

  return (
    <div>
        {
            isClicked ? 
            <button onClick={handleStatusChange} className={`border border-black rounded p-1 ${currentColor}`}>{status}</button> :
            <button onClick={handleStatusChange} className={`border border-black rounded p-1`}>{status}</button>
        }
    </div>
  )
}

export default StatusButton