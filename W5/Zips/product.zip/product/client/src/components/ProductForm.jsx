import React, {useState, useEffect} from 'react';
import axios from 'axios';

const ProductForm = ({currentProduct, setCurrentProduct}) => {

    const [ name, setName ] = useState("");
    const [ price, setPrice ] = useState(0);
    const [ description, setDescription ] = useState("");


    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/api/product", {
            name,
            price,
            description
        })
        .then(res => {console.log(res); console.log(res.data)})
        .catch(err => console.log(err));
        setName("");
        setPrice("");
        setDescription("");
    };

    const handleName = (e) => {
        setName(e.target.value);
    };

    const handlePrice = (e) => {
        setPrice(e.target.value);
    };
    const handleDescription = (e) => {
        setDescription(e.target.value);
    };
    
   return (
    <div >
        <h1>Product Manager</h1>
        <form onSubmit={handleSubmit} style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            padding: "20px",
            backgroundColor: "slategray",
            width: "17%",
            height: "200px",
            margin: "20px",
            marginLeft: "40%"
        }}>
            <div style= {{
                margin: "10px",
                alignSelf: "flex-start"
            }}>
                <label htmlFor="">Name: </label>
                <input type="text" onChange={handleName} value={name} />
            </div>
            <div style= {{
                margin: "10px",
                alignSelf: "flex-start"
            }}>
                <label htmlFor="">Price: </label>
                <input type="text" onChange={handlePrice} value={price} />
            </div>
            <div style= {{
                margin: "10px",
                alignSelf: "flex-start"
            }}>
                <label htmlFor="">Description: </label>
                <textarea type="text" onChange={handleDescription} value={description} ></textarea>
            </div>
            <button>Create</button>
        </form>
    </div>
  )
}

export default ProductForm